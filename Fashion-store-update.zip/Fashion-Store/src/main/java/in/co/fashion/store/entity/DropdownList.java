package in.co.fashion.store.entity;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
